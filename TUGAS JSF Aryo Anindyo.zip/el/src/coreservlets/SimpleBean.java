package coreservlets;

import javax.faces.bean.*;

@ManagedBean
public class SimpleBean {
  private String[] colors =
    { "blue", "hijau", "merah" };
  
  public String getMessage() {
    return("Hai, Dunia");
  }
  
  public String[] getColors() {
    return(colors);
  }
}